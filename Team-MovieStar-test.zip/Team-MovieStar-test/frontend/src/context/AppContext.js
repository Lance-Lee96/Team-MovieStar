// MainScreen에서 로그인 여부에 따라 버튼을 로그인 <-> 로그아웃
// 이를 위해 Context 활용
import { createContext } from "react";

export const AppContext = createContext();